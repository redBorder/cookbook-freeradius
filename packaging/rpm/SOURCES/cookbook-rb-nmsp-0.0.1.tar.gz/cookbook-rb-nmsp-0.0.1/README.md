# cookbook-rb-nmsp

Cookbook to install and configure redborder rb-nmsp
### Platforms

- Centos 7

### Chef

- Chef 12.0 or later


## Authors
Authors: Eduardo Reyes <eareyes@redborder.com>, Vicente Mesa <vimesa@redborder.com>
