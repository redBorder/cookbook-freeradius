#default attributes
#

default["rb-nmsp"]["registered"] = false
