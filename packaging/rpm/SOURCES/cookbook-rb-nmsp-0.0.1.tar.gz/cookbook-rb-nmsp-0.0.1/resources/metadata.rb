name             'rbnmsp'
maintainer       'redborder'
maintainer_email 'eareyes@redborder.com'
license          'All rights reserved'
description      'Installs/Configures cookbook-rb-nmsp'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.0.1'